package dataLinkage.HashedDataValiadtion;
import java.io.*;
import java.util.*;
import java.text.*;
import dataLinkage.HashedDataValiadtion.utility.*;
import dataLinkage.HashedDataValidation.hashedFileProcessor.*;

public class DoValidation {

	public static void main(String[] args)
	{	
		ProcessingHashedFiles.ReadAndProcessFiles();
	    System.out.println("All done!! type anything to close the program");
		
	    Scanner sc = new Scanner(System.in);
	    sc.next();	
	    sc.close();
	}

}
