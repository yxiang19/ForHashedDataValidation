package dataLinkage.HashedDataValiadtion.utility;

import java.io.*;
import java.util.*;
import java.text.*;
import java.lang.*;

public class Helper 
{
	private static String rootPath = Thread.currentThread().getContextClassLoader().getResource("").getPath();
	
	public static void WriteToLog(String logPath, String message)
	{
		WriteToLog(logPath, message, LogType.General);
	}
	
	public static void WriteToLog(String logPath, String message, LogType logType)
	{
		message = PrepareLogHeading() + message + PrepareLogTrailing();
		String fileName= null;
		if(!logPath.endsWith("/") && !logPath.endsWith("\\"))
			fileName = logPath + "/" + logType.toString() + "/log" + GetTodayDate("MMddyyyy") + ".txt";
		else
			fileName = logPath + "/" + logType.toString() + "/log" + GetTodayDate("MMddyyyy") + ".txt";
		
		try
		{
			Write(fileName, message);
		} 
		catch (IOException e) 
		{
			System.out.println("Failed to write file: " + fileName);
		}
	}
	
	//write to file or log...
	public static void Write(String fullPath, String message) throws IOException
	{
		String filePath = rootPath + "/" + fullPath; 
		File file = new File(filePath);
		FileWriter fileWriter;
		if(file.exists())
		{	
		  fileWriter = new FileWriter(filePath, true);
		}
		else 
		{
		   file.createNewFile();
		   fileWriter = new FileWriter(filePath);
		}
	    PrintWriter printWriter = new PrintWriter(fileWriter);
	    printWriter.print(message);
	    printWriter.close();
	}
	
	
	//read all files in the inbound folder for hashed data 
	public static File[] ReadAllFiles(String folder)
	{
		File files = null;
		try{
		    files = new File(rootPath + "/" +  folder);
		}
		catch(Exception ex) 
		{
			System.out.println("Failed to access folder: " + folder);
		}
		return files.listFiles();
	}
	
	public static String[] SplitString(String str, String delimiter)
	{
		return str.split(delimiter);	
	}
	
	private static String GetTodayDate(String format)
	{
		DateFormat df = new SimpleDateFormat(format);
	
		Date today = Calendar.getInstance().getTime();        
		
		return df.format(today);
	}
	
	private static String PrepareLogHeading()
	{
		String heading = "-----------------------------------------------------------------------------------------------";
			   heading += System.lineSeparator();
			   heading += GetTodayDate("yyyy-MM-dd'T'HH:mm:ss'Z'");
			   heading += System.lineSeparator();
	   return heading;
	}
	private static String PrepareLogTrailing()
	{
		String trailing = System.lineSeparator() + "-----------------------------------------------------------------------------------------------";
		trailing += System.lineSeparator();
		
		return trailing;
	}
}
