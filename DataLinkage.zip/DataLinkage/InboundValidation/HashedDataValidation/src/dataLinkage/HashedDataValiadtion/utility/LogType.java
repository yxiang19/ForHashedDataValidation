package dataLinkage.HashedDataValiadtion.utility;

public enum LogType 
{
  General,HashedDataValidation 
}
