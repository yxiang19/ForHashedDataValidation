package dataLinkage.HashedDataValiadtion.utility;
import java.util.Properties;
import java.io.*;

public class ReadConfigfile 
{
   private static Properties appProps = new Properties();
   private static String appConfig = "/config/config.properties";
   private static String appConfigPath = Thread.currentThread().getContextClassLoader().getResource("").getPath() + appConfig;
   
   public ReadConfigfile() 
   {
      LoadAppConfig();
   }
   
   private static void LoadAppConfig() 
   {	   
	   try 
	   {
	       appProps.load(new FileInputStream(appConfigPath));    
	   }
	   catch(FileNotFoundException ex)
	   {
		   
	   } catch (IOException e) 
	   {
		// TODO Auto-generated catch block
		e.printStackTrace();
	   }
	 
   }
   
   public String GetInboundFilePath()
   {   
	   return appProps.getProperty("inboundPath");	  
   }
  
   public String GetFileDelimiter()
   {
	   return appProps.getProperty("fileDelimiter");
   }
   
   public String[] GetValidFileExtension()
   {
	   String exts = appProps.getProperty("validFileExtension");
	   if(exts != null && exts != "")
		   return exts.split(";");
	   return null;
   }
   
   public String GetLogFilePath() 
   {
        return appProps.getProperty("logFilePath");
   }
   
   public String GetValidatedGoodPath()
   {
	   return appProps.getProperty("validatedGoodPath");
   }
   
   public String GetValidatedBadPath()
   {
	   return appProps.getProperty("validatedBadPath");
   }
}
