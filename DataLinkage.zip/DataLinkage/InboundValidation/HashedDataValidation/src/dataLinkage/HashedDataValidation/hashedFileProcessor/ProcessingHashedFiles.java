package dataLinkage.HashedDataValidation.hashedFileProcessor;
import dataLinkage.HashedDataValiadtion.utility.*;
import java.io.*;

public class ProcessingHashedFiles 
{
	private static ReadConfigfile rf = new ReadConfigfile();
	
	public static void ReadAndProcessFiles() 
	{
	   File[] files = Helper.ReadAllFiles(rf.GetInboundFilePath());
	   
	   for(int i=0; i<files.length; i++)
	   {
		   File file = files[i];
		   if(ValidateFile(file))
		   {
			   try {
			   BufferedReader br = new BufferedReader(new FileReader(file));
						   
			   String st; 
			   String fileName = file.getName();
               int rowCount = 0;
			   int goodRowCount = 0;
			   int badRowCount = 0;
			   String heading = null;
			   String goodFileName = rf.GetValidatedGoodPath() + fileName;
			   String badFileName = rf.GetValidatedBadPath() + fileName;
			   while ((st = br.readLine()) != null) 
			   {
				  if(rowCount == 0) 
				  {
				    heading = st;
				  }
				  else 
				  {
			         String[] splited = Helper.SplitString(st, rf.GetFileDelimiter());    
			         if(splited[0].isEmpty() || splited[1].isEmpty() || splited[2].isEmpty())
			         {
			        	 try 
			        	 {
			        	 if(goodRowCount == 0)
			        	 {
			        		Helper.Write(goodFileName, heading);
			        	    Helper.Write(goodFileName, st);	 
			        	 }
			        	 else
			        	 {
			        		 Helper.Write(goodFileName, st);	
			             }
			        	 goodRowCount++;
			        	 }
			        	 catch(IOException ex)
			        	 {
			        		 Helper.WriteToLog(rf.GetLogFilePath(), "Failed to write the data to file: " + goodFileName);
			        	 }
			         }	    	  
			         else 
			        {
			        	 try 
			        	 {
			        	 if(badRowCount == 0)
			        	 {
			        		Helper.Write(badFileName, heading);
			        	    Helper.Write(badFileName, st);
			        	 }
			        	 else
			        	 {
			        		 Helper.Write(badFileName, st);	
			             }
			        	    badRowCount++;
			        	 }
			        	 catch(IOException ex)
			        	 {
			        		 Helper.WriteToLog(rf.GetLogFilePath(), "Failed to write the data to file: " + badFileName);
			        	 }
			        }
				  }
			      rowCount++;
			   } 
			   br.close();
			   
			   Helper.WriteToLog(rf.GetLogFilePath(), "There are " + Integer.toString(goodRowCount) + " good hashed record(s) in file: " + fileName, LogType.HashedDataValidation);
			   Helper.WriteToLog(rf.GetLogFilePath(), "There are " + Integer.toString(badRowCount) + " bad hashed record(s) in file: " + fileName, LogType.HashedDataValidation);
			   				
			   }
			   catch(Exception ex)
			   {
				   Helper.WriteToLog(rf.GetLogFilePath(), "Read this file failed : " + file.getName());
			   }
		   }
		   else
		   {
			   Helper.WriteToLog(rf.GetLogFilePath(), "Can't read the file, check if it's a file and extension is valid : " + file.getName());
		   }
	   }
	}
	
	private static boolean ValidateFile(File file)
	{
		if(file.isFile())
		{
			//check file extension
			boolean isCorrectExt = false;
			String[] ext = rf.GetValidFileExtension();
			for(int i=0; i< ext.length; i++)
			{
			    if(file.getName().contains(ext[i]))
			    {
			    	isCorrectExt = true;
			    	break;
			    }			
			}

			return isCorrectExt;
		}
		
		return false;
	}
}
